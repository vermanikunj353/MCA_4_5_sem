#include<bits/stdc++.h>
using namespace std;

vector<string> splitter(string& s)
{
	int n = s.size();
	int i=0, j=0;
	vector<string> ans;
	while(i<n)
	{
		while(i<n && s[i] == ' ') i++;
		j = i;
		while(j<n && s[j] != ' ') j++;
		ans.push_back(s.substr(i, j-i));
		i = ++j;
	}
	return ans;
}

vector<vector<string>> readInput()
{
	ifstream fin("Input.txt");
	vector<vector<string>> ans;
	while(!fin.eof())
	{
		string s;
		getline(fin,s);
		ans.push_back(splitter(s));
	}
	return ans;
}

map<pair<string,string>,double> probabilityGenerator(vector<vector<string>>& data)
{
	map<pair<string,string>,double> cond_prob;
	int no_dataItem = data.size() - 1;
	int label = data[0].size() - 1;
	double prob = double(1)/no_dataItem;
	for(int i=1; i<=no_dataItem; i++)
	{
		for(int j=1; j<label; j++)
		{
			cond_prob[{data[i][j], data[i][label]}] += prob;
		}
	}
	return cond_prob;
}

void solution(vector<vector<string>>& data)
{
	set<string> s;
	int x = data[0].size()-1;
	for(int i=1; i<data.size(); i++) s.insert(data[i][x]);
	
	vector<string> labels(s.begin(), s.end());

	auto cp = probabilityGenerator(data);
	
	ofstream fout("Output.txt");
	
	for(int i=0; i<data[0].size(); i++) fout<<data[0][i]<<" ";
	fout<<"Calculated\n";
	
	for(int i=1; i<data.size(); i++)
	{
		for(int j=0; j<data[0].size(); j++)
		{
			fout<<data[i][j]<<" ";
		}
		int index = -1;
		double mx = -1;
		for(int k=0; k<labels.size(); k++)
		{
			double ans = 0;
			for(int j=1; j<data[0].size()-1; j++)
			{
				ans += cp[{data[i][j], labels[k]}];
			}
			if(mx < ans)
			{
				mx = ans;
				index = k;
			}
		}
		fout<<labels[index]<<endl;
	}
}

int main()
{
	vector<vector<string>> data = readInput();

	solution(data);
	
	return 0;
}
