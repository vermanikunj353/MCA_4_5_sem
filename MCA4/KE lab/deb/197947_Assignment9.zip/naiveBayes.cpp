#include<bits/stdc++.h>
using namespace std;

vector<string> tokens(string s);
vector<vector<string>> read(string file_name);
int classIndex(vector<vector<string>> data,string class_label);
void train_helper(vector<vector<string>> data,string class_label);
void calculate_probabilities();
void train(vector<vector<string>> data,string class_label);
void test(string file_name,string class_label,string output_file);
void print(vector<vector<string>> data);


struct hashPair {
    template <class T1, class T2>
    size_t operator()(const pair<T1, T2>& p) const
    {
        auto hash1 = hash<T1>{}(p.first);
        auto hash2 = hash<T2>{}(p.second);
        return hash1 ^ hash2;
    }
};

unordered_map<pair<string,string>,vector<int>,hashPair> feature_count;
unordered_map<pair<string,string>,vector<float>,hashPair> prob; 
unordered_map<string,int> class_count;
unordered_map<string,int> class_index;
int train_size;


vector<vector<string>> read(string file_name)
{
    ifstream f;
    string s;
    vector<vector<string>> data;
    f.open(file_name);
    while(f)
    {
        getline(f,s);
        data.push_back(tokens(s));
    }
    data.pop_back(); 
    train_size = data.size()-1;
    return data;
}
vector<string> tokens(string s)
{
    stringstream ss(s);
    string x;
    vector<string> v;
    while(ss>>x){
        v.push_back(x);
    }
    return v;
}
int classIndex(vector<vector<string>> data,string class_label){
    int index = -1;
    for(int i=0;i<data[0].size();i++)
    {
        if(data[0][i]==class_label) index=i;
    }
    return index;
}
void train_helper(vector<vector<string>> data,string class_label)
{
    int index = classIndex(data,class_label);
    int t=0;
    for(int i=1;i<data.size();i++) {
        string s = data[i][index];
        class_count[s]++;
        if(class_count[s] == 1) class_index[s] = t++;
    }
    for(int j=0;j<data[0].size();j++)
    {
        if(j==index) continue;
        for(int i=1;i<data.size();i++)
        {
            pair<string,string> p(data[0][j],data[i][j]);
            if(feature_count.find(p) == feature_count.end())
                feature_count[p] = vector<int>(class_index.size());
            int label_index = class_index[data[i][index]];
            feature_count[p][label_index]++;
        }
    }
}
void calculate_probabilities()
{
    for(auto i: feature_count)
    {
        pair<string,string> p = i.first;
        vector<int> t = i.second;
        vector<float> t_2;
        for(int i=0;i<t.size();i++){
            for(auto it = class_index.begin();it!=class_index.end();it++)
                if(it->second == i) t_2.push_back(float(t[i])/class_count[it->first]);
        }
        prob[p] = t_2;
    }
}
void train(vector<vector<string>> data,string class_label)
{
    train_helper(data,class_label);
    calculate_probabilities();
}
void test(string file_name,string class_label,string output_file)
{
    ofstream fout;
    fout.open(output_file);
    vector<vector<string>> data = read(file_name);
    int index = classIndex(data,class_label);
    vector<string> class_labels(class_index.size());
    for(auto it: class_index)
        class_labels[it.second] = it.first;
    if(file_name == "valid.txt") fout<<"Validation Data"<<endl<<endl;
    else fout<<"Testing Data"<<endl<<endl;
    for(int i=0;i<data[0].size();i++) fout<<data[0][i]<<" ";
    fout<<endl;
    for(int i=1;i<data.size();i++)
    {
        vector<float> bayes_probabilities(class_index.size(),1);
        for(int j=0;j<data[i].size();j++)
        {
            fout<<data[i][j]<<"  ";
            if(file_name=="valid.txt" and j==index) continue;
            pair<string,string> p(data[0][j],data[i][j]);
            for(int k=0;k<class_index.size();k++) bayes_probabilities[k]*= prob[p][k];
        }
        fout<<endl;
        for(int k=0;k<class_index.size();k++) bayes_probabilities[k]*= (float)class_count[class_labels[k]]/train_size;
        pair<string,float> prediction("",-1);
        for(int k=0;k<class_index.size();k++){
            if(bayes_probabilities[k]>prediction.second) {prediction.second = bayes_probabilities[k]; prediction.first = class_labels[k];}
            fout<<"P("<<class_labels[k]<<"/X) : "<<bayes_probabilities[k]<<endl;
        }
        fout<<"Predction : "<<prediction.first<<endl;

    }
}
void print(vector<vector<string>> data)
{
    for(int i=0;i<data.size();i++)
    {
        for(int j=0;j<data[i].size();j++)
        {
            cout<<data[i][j]<<"  ";
        }
        cout<<endl;
    }
}

int main()
{
    print(read("train.txt"));
    train(read("train.txt"),"Class:buys_computer");
    test("valid.txt","Class:buys_computer","valid_output.txt");
    test("test.txt","Class:buys_computer","test_output.txt");
}
